// AS-Bewerbung.ch – Interaktionen

document.addEventListener('DOMContentLoaded', function () {

  // --- Mobile Menü ---
  const toggle = document.getElementById('nav-toggle');
  const mobileMenu = document.getElementById('mobile-menu');
  const mobileClose = document.getElementById('mobile-close');

  if (toggle && mobileMenu) {
    toggle.addEventListener('click', () => {
      mobileMenu.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
  }
  if (mobileClose && mobileMenu) {
    mobileClose.addEventListener('click', () => {
      mobileMenu.classList.remove('open');
      document.body.style.overflow = '';
    });
  }
  // Menü schliessen bei Link-Klick
  document.querySelectorAll('.mobile-menu nav a').forEach(link => {
    link.addEventListener('click', () => {
      mobileMenu && mobileMenu.classList.remove('open');
      document.body.style.overflow = '';
    });
  });

  // --- FAQ Accordion ---
  document.querySelectorAll('.faq-question').forEach(btn => {
    btn.addEventListener('click', () => {
      const item = btn.closest('.faq-item');
      const isOpen = item.classList.contains('open');
      // Alle schliessen
      document.querySelectorAll('.faq-item.open').forEach(i => i.classList.remove('open'));
      if (!isOpen) item.classList.add('open');
    });
  });

  // --- Kontaktformular (Formspree) ---
  const form = document.getElementById('interview-check-form');
  if (form) {
    form.addEventListener('submit', async function (e) {
      e.preventDefault();
      const success = document.getElementById('form-success');
      const errorBox = document.getElementById('form-error');
      const submitBtn = form.querySelector('[type="submit"]');

      if (errorBox) errorBox.style.display = 'none';

      // Pflichtfelder prüfen
      if (typeof form.checkValidity === 'function' && !form.checkValidity()) {
        form.reportValidity();
        return;
      }

      const action = form.getAttribute('action') || '';

      // Solange noch keine echte Formspree-ID hinterlegt ist: Demo-Verhalten
      if (action.indexOf('IHRE_FORMULAR_ID') !== -1) {
        form.style.display = 'none';
        if (success) success.style.display = 'block';
        return;
      }

      const originalLabel = submitBtn ? submitBtn.textContent : '';
      if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = 'Wird gesendet …'; }

      try {
        const res = await fetch(action, {
          method: 'POST',
          body: new FormData(form),
          headers: { 'Accept': 'application/json' }
        });
        if (res.ok) {
          form.style.display = 'none';
          if (success) success.style.display = 'block';
        } else {
          throw new Error('Formspree response not ok');
        }
      } catch (err) {
        if (errorBox) errorBox.style.display = 'block';
        if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = originalLabel; }
      }
    });
  }

  // --- Aktiven Nav-Link setzen ---
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a, .mobile-menu nav a').forEach(link => {
    const href = link.getAttribute('href');
    if (href === currentPage) link.classList.add('active');
    if (currentPage === '' || currentPage === 'index.html') {
      if (href === 'index.html' || href === './') link.classList.add('active');
    }
  });

  // --- Smooth scroll für Anker-Links ---
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  // ============================================================
  //  LESERFÜHRUNG
  // ============================================================
  const hasJS = document.documentElement.classList.contains('js');
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // Lese-Fortschrittsanzeige
  const bar = document.createElement('div');
  bar.className = 'read-progress';
  document.body.appendChild(bar);

  const scrollCue = (function () {
    if (reduce) return null;
    const heroC = document.querySelector('.hero .container');
    if (!heroC) return null;
    const cue = document.createElement('div');
    cue.className = 'hero-scrollcue';
    cue.setAttribute('aria-hidden', 'true');
    cue.innerHTML = '<span>Weiterlesen</span><i></i>';
    heroC.appendChild(cue);
    return cue;
  })();

  function onScroll() {
    const h = document.documentElement;
    const max = h.scrollHeight - h.clientHeight;
    const y = window.scrollY || h.scrollTop;
    bar.style.width = (max > 0 ? (y / max) * 100 : 0) + '%';
    if (scrollCue) scrollCue.classList.toggle('gone', y > 40);
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  // Geführte Einblendung der Abschnitte
  if (hasJS && !reduce && 'IntersectionObserver' in window) {
    document.querySelectorAll('.section > .container').forEach(c => c.classList.add('reveal-group'));
    document.querySelectorAll('.leitsatz').forEach(c => c.classList.add('reveal'));

    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -7% 0px' });

    document.querySelectorAll('.reveal, .reveal-group').forEach(el => io.observe(el));
  }

});
